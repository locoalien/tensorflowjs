# This repository has been archived in favor of tensorflow/tfjs.

This repo will remain around for some time to keep history but all future PRs should be sent to [tensorflow/tfjs](https://github.com/tensorflow/tfjs) inside the [tfjs-vis](https://github.com/tensorflow/tfjs/tree/master/tfjs-vis) folder.

All history and contributions have been preserved in the monorepo.
