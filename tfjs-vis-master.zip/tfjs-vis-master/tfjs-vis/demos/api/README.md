# tfjs-vis renderers demo

A page showing examples of all the tfjs-vis render.* functions.

See a live version of this [here](https://storage.googleapis.com/tfjs-vis/api/dist/index.html).

To run this locally run `yarn watch-api` from the `demos` folder
