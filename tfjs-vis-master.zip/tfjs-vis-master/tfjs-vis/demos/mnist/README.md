# tfjs-vis mnist training demo

A demonstration of using tfjs-vis to look at training progress and perform model evaluation.

See a live version of this [here](https://storage.googleapis.com/tfjs-vis/mnist/dist/index.html).

To run this locally run `yarn watch-api` from the `demos` folder
