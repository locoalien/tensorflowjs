# tfjs-vis mnist internals demo

A demonstration of using tfjs-vis to look at model internals such as summaries and
activations

See a live version of this [here](https://storage.googleapis.com/tfjs-vis/mnist_internals/dist/index.html).

To run this locally run `yarn watch-api` from the `demos` folder
