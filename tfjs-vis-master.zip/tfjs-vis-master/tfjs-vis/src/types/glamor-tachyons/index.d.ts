// Minimal typings for glamor-tachyhons

declare module 'glamor-tachyons' {
  export function tachyons(input: string|{}): {};
}
